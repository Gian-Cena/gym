function doClear()
{
    document.SignUp.userid.value = "";
    document.SignUp.passid.value = "";
    document.SignUp.username.value = "";
    document.SignUp.address.value = "";
    document.SignUp.country.value = "";
    document.SignUp.zip.value = "";
    document.SignUp.email.value = "";
    document.SignUp.desc.value = "";
    return;
}

function doSubmit()
{
    if(validateText() == false)
    {
        alert("Required data missing in Step 1");
        return;
    }
    alert("Thank You, We Will Contact You Soon!");
    return;
}

function validateText()
{
    var userid = document.SignUp.userid.value; 
    var passid = document.SignUp.passid.value;
    var username = document.SignUp.username.value;
    var address = document.SignUp.address.value;
    var zip = document.SignUp.zip.value;
    var email = document.SignUp.email.value;

    if (userid == 0 || passid == 0 || username == 0 || zip == 0 || email == 0) return false; 
}